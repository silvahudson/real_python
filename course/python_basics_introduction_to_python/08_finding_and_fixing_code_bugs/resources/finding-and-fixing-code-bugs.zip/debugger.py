for i in range(1, 4):
    j = i * 2
    print(f"i is {i} and j is {j}")
