from shapes import Point, Square

from dogs import Doggo, JackRussellTerrier, Dachshund, Bulldog

bottom_left = Point(0, 0)
bottom_right = Point(10, 0)
top_left = Point(0, 10)
top_right = Point(10, 10)

square = Square([bottom_left, bottom_right, top_left, top_right])

# ---

miles = Doggo("Miles", 4)
buddy = Doggo("Buddy", 9)
jack = Doggo("Jack", 3)
jim = Doggo("Jim", 5)

buddy.speak("Yap")
jim.speak("Woof")
jack.speak("Woof")

miles = JackRussellTerrier("Miles", 4)
buddy = Dachshund("Buddy", 9)
jack = Bulldog("Jack", 3)
jim = Bulldog("Jim", 5)


print(jack)
jim.speak("Woof")

print(type(miles))  # <class '__main__.JackRussellTerrier'>
print(isinstance(miles, Doggo))  # True
print(isinstance(miles, Bulldog))  # False
print(isinstance(jack, JackRussellTerrier))  # True


miles = JackRussellTerrier("Miles", 4)

miles.speak()
miles.speak("Grrr")
