class WrongNumberOfPoints(Exception):
    pass


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __add__(self, other):
        self.x = self.x + other.x
        self.y = self.y + other.y


class Shape:
    def __init__(self, points):
        self.points = points


class Square(Shape):
    def __init__(self, points):
        if len(points) != 4:
            raise WrongNumberOfPoints
        super().__init__(points)


class Triangle(Shape):
    def __init__(self, points):
        if len(points) != 3:
            raise WrongNumberOfPoints
        super().__init__(points)
