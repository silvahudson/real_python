# Build a Dog class
# Create a class attribute species "Canis familiaris"
# Each Dog should have a name and age
# It should print nicely
# It should be able to speak a `sound` (argument)
class Dog:

    species = "Canis familiaris"

    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f"{self.name} is {self.age} years old"

    def speak(self, sound):
        return f"{self.name} says {sound}"
