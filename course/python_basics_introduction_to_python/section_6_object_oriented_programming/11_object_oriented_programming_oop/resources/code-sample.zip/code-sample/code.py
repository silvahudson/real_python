from doggo import Doggo
from point import Point


# Without classes

kirk = ["James Kirk", 34, "Captain", 2265]
spock = ["Spock", 35, "Science Officer", 2254]
mccoy = ["Leonard McCoy", "Chief Medical Officer", 2266]

kirk[1]  # 34
spock[1]  # 35
mccoy[1]  # "Chief Medical Officer"

point = (1, 2)

point[0] = 1  # this represents x axis
point[1] = 2  # y axis


origin = Point(0, 0)

target = Point(10, 15)


origin.x  # 0
target.y  # 15

Point.dimensions  # 2
origin.dimensions  # 2

target.x = 12
target.x  # 12

Point.dimensions = 3
Point.dimensions  # 3

origin = Point(0, 0)
target = Point(0, 0)

origin == target  # False
origin is target  # False

isinstance(origin, Point)  # True
isinstance(target, Point)  # True
type(origin) == type(target)  # True


miles = Doggo("Miles", 4)

miles.description()  # 'Miles is 4 years old, and is a good doggo.'

miles.speak("Woof Woof")  # 'Miles says Woof Woof'

miles.speak("Bow Wow")  # 'Miles says Bow Wow'

# Printing and Representation

names = ["David", "Dan", "Joanna", "Fletcher"]
print(names)  # ['David', 'Dan', 'Joanna', 'Fletcher']

print(miles)

names = ["David", "Dan", "Joanna", "Fletcher"]
print(names)  # ['David', 'Dan', 'Joanna', 'Fletcher']

print(miles)  # <__main__.Doggo object at 0x00aeff70>

miles = Doggo("Miles", 4)
print(miles)  # 'Miles is 4 years old'

center = Point(50, 50)
print(center)  # Point at x:50, y: 50

center = Point(50, 50)
print(center)  # Point at x:50, y: 50

distance = Point(25, 25)

center + distance

center = Point(50, 50)
print(center)  # Point at x:50, y: 50

distance = Point(25, 25)

center + distance

print(center)  # Point at x:75, y: 75
