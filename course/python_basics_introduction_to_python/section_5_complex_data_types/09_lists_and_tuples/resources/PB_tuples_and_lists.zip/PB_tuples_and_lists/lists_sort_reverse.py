numbers = [1, 10, 5, 3]
numbers.sort(reverse=True)

print(numbers)
# [10, 5, 3, 1]
