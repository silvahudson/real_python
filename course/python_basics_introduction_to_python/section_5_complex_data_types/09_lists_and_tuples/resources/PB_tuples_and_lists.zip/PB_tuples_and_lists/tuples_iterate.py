numbers = (1, 2, 3)

for number in numbers:
    print(number)
