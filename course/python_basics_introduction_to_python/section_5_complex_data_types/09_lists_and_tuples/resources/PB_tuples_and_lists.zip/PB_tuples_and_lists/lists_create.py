numbers = [1, 2, 3]

# Lists are mutable
numbers[0] = "One"

print(numbers)
