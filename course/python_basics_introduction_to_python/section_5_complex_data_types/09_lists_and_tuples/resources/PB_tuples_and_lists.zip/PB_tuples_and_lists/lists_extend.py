numbers = [1, 2]

numbers.extend([3, 4])
print(numbers)

numbers.extend((5, 6))
print(numbers)
