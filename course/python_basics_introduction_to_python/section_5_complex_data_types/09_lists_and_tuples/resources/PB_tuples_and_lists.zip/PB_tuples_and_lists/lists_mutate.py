numbers = [1, 2, 3]

numbers[1] = 20
print(numbers)
