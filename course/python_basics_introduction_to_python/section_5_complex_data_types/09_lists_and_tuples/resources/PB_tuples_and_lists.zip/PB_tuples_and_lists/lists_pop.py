numbers = [1, 2, 3, 4]

print(numbers.pop(2))  # Index position
print(numbers)

print(numbers.pop())  # Default: last element
print(numbers)
