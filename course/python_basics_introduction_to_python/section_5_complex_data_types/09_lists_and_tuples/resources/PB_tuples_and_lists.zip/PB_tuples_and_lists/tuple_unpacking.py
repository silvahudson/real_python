# Create a tuple literal
rgb_lime_green = 50, 205, 50
print(rgb_lime_green)
print(type(rgb_lime_green))

# Unpack the tuple
red, green, blue = rgb_lime_green

print(red)
print(green)
print(blue)
