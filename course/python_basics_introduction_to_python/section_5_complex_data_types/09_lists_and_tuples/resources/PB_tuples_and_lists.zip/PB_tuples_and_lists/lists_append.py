numbers = [1, 2]

numbers.append(3)
print(numbers)
