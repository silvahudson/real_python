maori_words = [["whānau", "family"], ["kai", "food"], ["aroha", "love"]]

print(maori_words[2][0])
print(maori_words[2][1])
