print(("🐭", "🐻", "🦊", "🐷"))

numbers = 1, 2, 3
print(numbers)

employee = (1, "Adisa", "Software Engineer")
print(employee)

print(tuple("Python"))
