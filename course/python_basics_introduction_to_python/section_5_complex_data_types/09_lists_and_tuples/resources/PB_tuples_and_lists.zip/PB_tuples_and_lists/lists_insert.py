numbers = [1, 3]

numbers.insert(1, "two")  # (index_position, element)
print(numbers)
