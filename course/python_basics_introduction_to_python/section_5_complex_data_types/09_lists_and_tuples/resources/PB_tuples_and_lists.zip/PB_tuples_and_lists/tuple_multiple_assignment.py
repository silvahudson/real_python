employee_id, name, role = 1, "Adisa", "Software Engineer"

print(employee_id)
print(name)
print(role)

latitude, longitude = 49.37, -123.37

print(latitude)
print(longitude)
