numbers = (1, 2, 3)

numbers[0] = 2  # TypeError
