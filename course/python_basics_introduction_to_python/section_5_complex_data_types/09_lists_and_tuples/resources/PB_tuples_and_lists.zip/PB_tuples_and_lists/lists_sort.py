colors = ["red", "yellow", "green", "blue"]
colors.sort()
print(colors)
# ['blue', 'green', 'red', 'yellow']

numbers = [1, 10, 5, 3]
numbers.sort()
print(numbers)
# [1, 3, 5, 10]
