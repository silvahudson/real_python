vowels = ("a", "e", "i", "o", "u")

print("o" in vowels)
print("x" in vowels)
