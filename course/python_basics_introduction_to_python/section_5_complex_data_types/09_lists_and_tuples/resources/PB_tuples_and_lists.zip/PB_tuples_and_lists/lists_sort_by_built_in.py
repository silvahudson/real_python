colors = ["red", "yellow", "green", "blue"]

colors.sort(key=len)

print(colors)
# ['red', 'blue', 'green', 'yellow']
