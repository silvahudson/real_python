data = ((1, 2), (3, 4))

index = 1
for row in data:
    print(f"Row {index} sum: {sum(row)}")
    index += 1


# Using the built-in enumerate() function:
# https://realpython.com/python-enumerate/
for row_number, row in enumerate(data, start=1):
    print(f"Row {row_number} sum: {sum(row)}")
