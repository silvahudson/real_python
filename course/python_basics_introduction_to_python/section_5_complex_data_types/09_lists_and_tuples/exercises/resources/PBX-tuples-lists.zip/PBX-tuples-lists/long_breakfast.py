breakfast = "eggs, fruit, orange juice".split(", ")

print(breakfast)
print(len(breakfast) == 3)

lengths = [len(item) for item in breakfast]
print(lengths)
