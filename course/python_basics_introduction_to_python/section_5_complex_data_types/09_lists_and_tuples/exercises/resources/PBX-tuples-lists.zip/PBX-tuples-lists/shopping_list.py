food = ["rice", "beans"]

food.append("broccoli")
print(food)

food.extend(["bread", "pizza"])
print(food)

print(food[:2])
# This is equivalent:
print(food[0:2])

print(food[-1])
