location = (6.51, 3.39, "Lagos", "Nigeria")

print(location[2])  # 'Lagos'

latitude, longitude, city, country = location

print(latitude)  # 6.51
print(longitude)  # 3.39
print(city)  # Lagos
print(country)  # Nigeria
