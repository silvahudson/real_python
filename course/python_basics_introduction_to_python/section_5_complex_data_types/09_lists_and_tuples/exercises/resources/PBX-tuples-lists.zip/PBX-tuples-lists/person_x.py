my_name = tuple("Martin")
print(my_name)

print("x" in my_name)  # False

print(my_name[1:])  # ('a', 'r', 't', 'i', 'n')
