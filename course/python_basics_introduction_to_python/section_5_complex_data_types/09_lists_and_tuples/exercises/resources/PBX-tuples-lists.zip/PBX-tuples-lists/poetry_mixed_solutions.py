import copy
import random

# Define nouns, verbs, adjectives, prepositions, adverbs
nouns = [
    "badger",
    "horse",
    "aardvark",
    "mouse",
    "gorilla",
    "elephant",
    "eagle",
    "sparrow",
]
verbs = [
    "hugs",
    "bounces",
    "meows",
    "hauls",
    "whispers",
    "flutters",
    "gallops",
    "shimmers",
]
adjectives = [
    "furry",
    "incredulous",
    "fragrant",
    "exuberant",
    "glistening",
    "melancholic",
    "serene",
]
prepositions = [
    "against",
    "after",
    "into",
    "beneath",
    "upon",
    "for",
    "in",
    "like",
    "over",
    "within",
]
adverbs = [
    "curiously",
    "extravagantly",
    "graciously",
    "reluctantly",
    "meticulously",
    "vigorously",
]

words = (nouns, verbs, adjectives, prepositions, adverbs)


def make_poem(words):
    """Create a randomly generated poem, returned as a multi-line string."""

    # Create a deep copy of the tuple of lists
    words = copy.deepcopy(words)

    # Pull three different nouns
    nouns = []
    for _ in range(3):
        noun = random.choice(words[0])
        words[0].remove(noun)
        nouns.append(noun)

    # Pull three different verbs
    verbs = []
    for _ in range(3):
        verb = random.choice(words[1])
        words[1].remove(verb)
        verbs.append(verb)

    # Pull three different adjectives
    random.shuffle(words[2])
    adjectives = [words[2].pop() for _ in range(3)]

    # Pull two different prepositions
    prepositions = random.sample(words[3], k=2)

    # Pull one adverb
    adverb = random.choice(words[4])

    # Decide which article to use
    if adjectives[0][0].lower() in "aeiou":  # First letter is a vowel
        article = "An"
    else:
        article = "A"

    # Create the poem
    poem = (
        f"{article} {adjectives[0]} {nouns[0]}\n\n"
        f"{article} {adjectives[0]} {nouns[0]} "
        f"{verbs[0]} {prepositions[0]} the {adjectives[1]} {nouns[1]}\n"
        f"{adverb}, the {nouns[0]} {verbs[1]}\n"
        f"the {nouns[1]} {verbs[2]} {prepositions[1]} "
        f"the {adjectives[2]} {nouns[2]}"
    )

    return poem


for _ in range(10):
    print(make_poem(words))
