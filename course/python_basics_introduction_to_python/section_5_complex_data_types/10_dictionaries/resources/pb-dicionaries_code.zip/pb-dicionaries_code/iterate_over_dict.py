capitals = {
    "California": "Sacramento",
    "New York": "Albany",
    "Texas": "Austin",
}

for state in capitals:
    print(state)

for state in capitals:
    print(state, capitals[state])

for state, city in capitals.items():
    print(state, city)
