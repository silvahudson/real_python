my_dog = {
    "name": "Frieda",
    "age": 5,
    "nicknames": ["Fru-Fru", "Lady McNugget"],
    "hungry": True,
}
