my_dog = {
    "name": "Frieda",
    "age": 6,
    "nicknames": ["Fru-Fru", "Lady McNugget"],
    "hungry": True,
}

del my_dog["hungry"]

if my_dog["hungry"] in my_dog:
    print(my_dog["hungry"])
