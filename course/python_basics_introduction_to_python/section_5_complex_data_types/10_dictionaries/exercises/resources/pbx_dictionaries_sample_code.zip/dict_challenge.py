import random

captains = dict(
    [
        ("Enterprise", "Picard"),
        ("Voyager", "Janeway"),
        ("Defiant", "Sisko"),
    ]
)

captains["Old Bessie"] = "Leela"
spaceships = list(captains.keys())
positions = random.sample(spaceships, len(spaceships))
winners = {place: "unknown" for place in range(1, 3 + 1)}

for index, spaceship in enumerate(positions[:3]):
    position = index + 1
    winners[position] = spaceship

for spaceship, captain in captains.items():
    if spaceship == winners[1]:
        print(f"Congratulations, {captain}!")
    elif spaceship not in winners.values():
        print(f"Better luck next time, {captain}.")
