# Write a function that simulates the roll of a die.
from random import randint


def roll():
    return randint(1, 6)


print(roll())
print(roll())
print(roll())
print(roll())
print(roll())
